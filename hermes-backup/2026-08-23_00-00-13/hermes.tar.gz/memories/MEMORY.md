User requires ALL dates in app to be Jalali/Shamsi (شمسی) — every section including week grid, logs, stats, calendar, export
§
User wants assignment (تکلیف) and exam (امتحان) features fully integrated with subjects and Jalali dates
§
User expects capabilities to be logically ordered with navigation and verified end-to-end (21-check audit) — not just added
§
User is frustrated by duplicate subjects and calendar/date UTC bugs — expects dedup via UNIQUE index + 409 and local date handling (todayLocal, addDays local)