# Railway — Duplicate Service + Stale Build (2026-08-22)

## Symptoms
- Dashboard shows two services both `source.repo == "penalerko/Panel"` : `weekly-planner` (with domain) + `Panel` (no domain), both `Online`.
- Settings/GitHub status shows `GitHub Repo not found` even though repo is public and `penalerko/Panel` exists.
- New pushes to `main` do not appear on live domain (HTML len stale, missing `Intl` patch).

## Diagnosis
- Duplicate service created during earlier debugging when `serviceConnect`/`serviceCreate` retried; Railway keeps both.
- Stale build: `serviceInstanceDeploy(serviceId, environmentId)` alone can re-deploy cached image without pulling latest GitHub commit.

## Fix
```graphql
# 1. Delete duplicate (keep the one with domain)
mutation { serviceDelete(id: "duplicate Panel serviceId") }  # → true

# 2. Re-connect GitHub source on the survivor (needs subfields)
mutation { serviceConnect(id: "weekly-planner serviceId", input: { repo: "penalerko/Panel", branch: "main" }) { id name } }

# 3. Deploy with latestCommit: true to pull GitHub HEAD
mutation { serviceInstanceDeploy(serviceId: "...", environmentId: "...", latestCommit: true) }
# Alternative: serviceInstanceDeployV2(serviceId, environmentId)
```

## Verification
- `query { project(id: "...") { services { edges { node { id name } } } } }` → only `weekly-planner` + `mysql`.
- `GET /?t=now` length and markers (`Intl.DateTimeFormat`, `۳.۱`) match `raw.githubusercontent.com/penalerko/Panel/main/templates/index.html`.
- Poll `deployments` until `SUCCESS`, then `deploymentLogs` shows `Listening at: 0.0.0.0:8080`.
