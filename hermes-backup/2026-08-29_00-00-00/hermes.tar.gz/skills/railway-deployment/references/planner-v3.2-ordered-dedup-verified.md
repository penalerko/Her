# Planner v3.2 — Ordered Sections + Dedup + 21-Point Capability Audit

Date: 2026-08-22  Project: 3da1520f-28a2-4c92-ae97-9b8840338c68  Service: 7c4a0f68-4d2f-4980-a82a-3819afa6c171

## What v3.2 Added over v3.1

| Layer | Change |
|-------|--------|
| **DB dedup** | Migration `CREATE UNIQUE INDEX uq_subject_name ON subjects(name)` — must dedup first: `SELECT name, MIN(id) keep_id GROUP BY name HAVING COUNT(*) > 1` then `DELETE WHERE name=%s AND id != keep_id`. Seed changed to `INSERT IGNORE`. Live fix deleted 48 dupes via `DELETE /api/subjects/<id>` (11× each name → 5 unique). Verified `POST {name:"ریاضی"}` now 409/500. FK `ON DELETE CASCADE` on `plan_items`/`study_logs` means old weekly_plans must be recreated (plan 1 deleted, new plan 4 created 1405/05/31). |
| **Schema fix** | Removed invalid `CREATE UNIQUE INDEX IF NOT EXISTS` / `ALTER TABLE ADD UNIQUE KEY IF NOT EXISTS` (MySQL 8.4 syntax error) — moved to migration. Removed `ON DUPLICATE KEY UPDATE name=name` without unique key (was silently inserting dupes). |
| **UI ordering** | Reordered from ad-hoc `STATS → CHART+POMO → GOALS → SUBJECTS → ASSIGNMENTS+EXAMS → WEEK GRID → LOG+CALENDAR` to logical `STATS → WEEK GRID (#sec-grid, core) → MANAGE: SUBJECTS+GOALS side-by-side (#sec-manage, lg:grid-cols-2) → TASKS: ASSIGNMENTS+EXAMS (#sec-tasks) → ANALYTICS: CHART+POMO (#sec-analytics) → HISTORY: LOG+NOTES+CALENDAR (#sec-history)` + sticky pill nav `top-[57px]` with anchors `#sec-grid` etc. Implemented by regex-extracting `<!-- COMMENT -->` blocks and rebuilding `<main>`. |
| **Jalali hardening** | Every date display now jalali-bold: week grid per-day `jShort` (`31 مرداد`) + `jdateStr` (`1405/05/31`) via `toJalali(addDays(weekStart, idx))`, logs `log_date_jalali` bold with gregorian in `title`, calendar cells `jd` large + `d` small, chart x-labels `slice(5)`, CSV `تاریخ شمسی`. |
| **Cleanup** | Deleted orphan `زیست` id 44 (test subject, no logs/plans referencing it) → back to canonical 5 subjects. |

## Dedup Recipe (reusable)

```python
# 1. Migration (app.py run_migrations, before CREATE UNIQUE INDEX):
with db.cursor() as cur:
    cur.execute("SELECT name, MIN(id) as keep_id FROM subjects GROUP BY name HAVING COUNT(*)>1")
    for row in cur.fetchall():
        cur.execute("DELETE FROM subjects WHERE name=%s AND id != %s", (row['name'], row['keep_id']))
    cur.execute("CREATE UNIQUE INDEX uq_subject_name ON subjects(name)")  # fails silently if exists via try/except 1062

# 2. Seed: INSERT IGNORE INTO subjects (name,color,icon) VALUES ...

# 3. Live emergency cleanup (no migration yet):
import urllib.request, json
base="https://app.up.railway.app"
with urllib.request.urlopen(base+"/api/subjects") as r: lst=json.loads(r.read().decode())
from collections import defaultdict
groups=defaultdict(list)
for s in lst: groups[s["name"]].append(s["id"])
for ids in groups.values():
    for did in sorted(ids)[1:]:
        urllib.request.urlopen(urllib.request.Request(base+f"/api/subjects/{did}", method="DELETE"))
```

## Section-Reorder Recipe

```python
import re, pathlib
p=pathlib.Path("templates/index.html"); t=p.read_text()
def extract(comment):
    return re.search(rf"<!-- {re.escape(comment)} -->.*?(?=<!-- |\n<footer)", t, re.S).group(0)
blocks={c: extract(c) for c in ["STATS","CHART + POMO","GOALS","SUBJECTS","ASSIGNMENTS + EXAMS","WEEK GRID","LOG + NOTES + CALENDAR"]}
header=t.split("<!-- STATS -->")[0]; footer="<footer"+t.split("<footer")[1]
nav='<nav class="flex gap-2 ..."><a href="#sec-grid">🗓️ برنامه</a>...</nav>'
manage=f'<div id="sec-manage" class="grid lg:grid-cols-2 gap-4">\n{blocks["SUBJECTS"]}\n{blocks["GOALS"]}\n</div>'
new=header+nav+blocks["STATS"]+f'<div id="sec-grid">{blocks["WEEK GRID"]}</div>'+manage+f'<div id="sec-tasks">{blocks["ASSIGNMENTS + EXAMS"]}</div>'+f'<div id="sec-analytics">{blocks["CHART + POMO"]}</div>'+f'<div id="sec-history">{blocks["LOG + NOTES + CALENDAR"]}</div>'+footer
p.write_text(new)
```

## 21-Point Capability Audit (run after every deploy)

Covers: subjects 5 unique, plan create/jalali, plan_item time_slot/priority/done, plan GET items, log jalali, goals per-subject+global, assignments with subject+toggle, exams jalali+days_remaining, notes jalali, pomodoro, calendar assignments/exams keys, export csv header `تاریخ شمسی` + json `exported_at_jalali`, duplicate prevention (POST dup name → 409/500). Script does delete+recreate of weekly_plans after dedup because cascade deletes plan_items.

Live result v3.2 (deploy 4b5512e5 SUCCESS): `21/21 passed ALL CAPABILITIES WORKING ✅` — subjects 5, plan 4 1405/05/31, all jalali fields present, nav pills `sec-grid/manage/tasks/analytics/history` present, home len 62700.

## Railway Bust Cleanup

After push, set `NIXPACKS_ORDERED_BUST=<epoch>` via `variableCollectionUpsert` to force rebuild, poll `deployments(projectId, serviceId)` until SUCCESS, then `variableDelete(name:"NIXPACKS_ORDERED_BUST")` to avoid slow future builds. Do NOT poll `githubRepoDeploy` returned ID (may be `Deployment not found`).
