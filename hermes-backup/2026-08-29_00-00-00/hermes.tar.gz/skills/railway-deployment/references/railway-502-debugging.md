# Railway 502 / Application failed to respond — Debugging Playbook

**Incident:** 2026-08-22 weekly-planner — `https://weekly-planner-production-fcf8.up.railway.app` returned `502 Application failed to respond` despite `deployment status: SUCCESS`.

**Root cause (in order of impact):**

1. **Domain targetPort mismatch (PRIMARY — fixed 502 instantly):**
   - Symptom: `deploymentLogs` shows `Listening at: http://0.0.0.0:8080` (Railway injects `$PORT=8080`) but `serviceInstances { domains { serviceDomains { targetPort: 5000 } } }` still pointed to 5000.
   - Fix: `serviceDomainUpdate` to 8080:
     ```graphql
     mutation { serviceDomainUpdate(input: { domain: "app-xxx.up.railway.app", serviceDomainId: "<id>", serviceId: "<sid>", environmentId: "<eid>", targetPort: 8080 }) }
     ```
   - Verify: `health` returns 200 within 10s of update; `httpLogs` stops showing 502.

2. **runtime.txt broke Railpack/mise:**
   - `runtime.txt` with `python-3.11.9` triggered `mise ERROR Failed to install core:python@3.11.9: No GitHub artifact attestations found`. Build `FAILED` with opaque `failed to solve: process "mise install" did not complete`.
   - Fix: delete `runtime.txt` entirely, let Nixpacks auto-detect (Railway now uses `python:3.14.7-slim`); or set `NIXPACKS_PYTHON_VERSION=3.11` via env var. Check `buildLogs(deploymentId, limit: 500)` — look for `mise python@... install` vs `pip install` success.

3. **Blocking DB init on startup:**
   - Original `with app.app_context(): init_db()` at import hung healthcheck when MySQL `caching_sha2_password` needed `cryptography` not yet installed. Kept returning `db: error` and eventually 502.
   - Fix: lazy init via `@app.before_request` with global guard; `health` always returns 200 (`status:ok, warning:db not connected yet`) so Railway doesn't mark unhealthy. Add `connect_timeout=5` and fallback chain: `MYSQL_URL` → `MYSQLHOST`/`MYSQLUSER` → `DB_HOST` → `localhost`.

4. **cryptography missing for MySQL 8.4:**
   - `pymysql` without `cryptography==44.0.0` fails `caching_sha2_password`. Added to `requirements.txt` + runtime hotfix `pip install cryptography` at startup for already-built image.
   - Next build must use `deploymentRedeploy(id, usePreviousImageTag: false)` to force rebuild and pick up new `requirements.txt`.

5. **Healthcheck path:**
   - Set `healthcheckPath: "/health"` + `healthcheckTimeout: 30` via `serviceInstanceUpdate(serviceId, environmentId, input: { healthcheckPath, healthcheckTimeout })`.

**Log taxonomy:**
- `buildLogs(deploymentId)` = builder (Railpack, `pip install`, `mise`). Use for `FAILED`.
- `deploymentLogs(deploymentId)` = runtime (`Starting Container`, `gunicorn`). Use for `SUCCESS` + 502.
- A `SUCCESS` with only `Starting Container` (1 line) = runtime crashed before bind; inspect `buildLogs` for missing deps.

**Config corruption trap:**
- `railway logs` / any CLI call without valid `RAILWAY_API_TOKEN` overwrites `~/.railway/config.json` and `/data/.railway/config.json` to `{}` ("Unable to parse config file, regenerating") and breaks `railway link`. Restore after failures:
  ```json
  {"projects": {"/data/workspace/weekly-planner": {"environment":"<eid>","project":"<pid>","service":"<sid>","projectPath":"/data/workspace/weekly-planner"}}}
  ```
  Copy to both `/data/.railway/config.json` and `~/.railway/config.json`.

**Deployment trigger when `railway up` 401s:**
- `railway up --detach --json --service X` with `RAILWAY_API_TOKEN` frequently 401 Unauthorized. Workaround:
  1. Push to GitHub via Contents API `PUT /repos/{owner}/{repo}/contents/{path}` (base64) when fine-grained PAT blocks `git push` (`https://oauth2:<pat>@github.com/...` may still 403 without Repo Contents RW).
  2. `railway api 'mutation { deploymentRedeploy(id: "<lastDeployId>", usePreviousImageTag: false) { id status } }'` — `false` rebuilds from GitHub; `true`/omitted just restarts image.
  Poll `deployment(id)` until `SUCCESS`/`FAILED`.

**Tokens that worked:**
- GitHub fine-grained PAT: `Authorization: Bearer <pat>` (not `token`); push URL `https://oauth2:<pat>@github.com/penalerko/Panel.git`.
- Railway: `RAILWAY_API_TOKEN` (not `RAILWAY_TOKEN`) for `railway api` and `railway deployment redeploy --from-source`.

**Verification (2026-08-22 17:35 UTC):**
- `https://weekly-planner-production-fcf8.up.railway.app/health` → `{"status":"ok","db":"connected"}` (after all fixes)
- `https://weekly-planner-production-fcf8.up.railway.app/` → 200, Persian UI rendered (Vazirmatn, Chart.js, weekly grid Sat–Fri).

**Session:** weekly-planner Flask + MySQL (pymysql) + gunicorn, Railway project `3da1520f-28a2-4c92-ae97-9b8840338c68`, service `7c4a0f68-4d2f-4980-a82a-3819afa6c171`, domain `weekly-planner-production-fcf8.up.railway.app` (id `defed74e-0de2-45ca-9b3c-ec9e8ba4d8d5`).
