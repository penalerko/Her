# Weekly Planner v3 — Jalali (Shamsi) + Assignments + Exams

**Date:** 2026-08-22 **Project:** `3da1520f-28a2-4c92-ae97-9b8840338c68` **Service:** `7c4a0f68-4d2f-4980-a82a-3819afa6c171`
**Stack:** Flask + MySQL 8.4 + jdatetime 5.2 + gunicorn 23 + Tailwind + Chart.js

## What v3 Added over v2

| Layer | Change |
|-------|--------|
| **DB** | +2 tables: `assignments(id, subject_id, title, description, due_date, priority, status)` and `exams(id, subject_id, title, exam_date, exam_time, location, description)`. `app_settings` seeded with `date_mode=jalali`. `requirements.txt` adds `jdatetime==5.2.0`. |
| **Backend helpers** | `gregorian_to_jalali()`, `to_jalali_str(gdate)`, `jalali_today_str()`, `enrich_jalali(obj, fields)` — tries `jdatetime` first, falls back to pure-Python 33-year cycle. Cache `_jalali_cache`. Every response that carries a `DATE` now also carries `*_jalali` and `*_days_remaining` (exams). |
| **API new** | `GET/POST /api/assignments`, `PATCH/PUT/DELETE /api/assignments/<id>` (status toggle `pending↔done`, overdue detection `due_date < today`), `GET/POST /api/exams` (+ `days_remaining` computed server-side), `PUT/DELETE /api/exams/<id>`. Extended: `GET /api/stats` → `week_start_jalali`, `week_end_jalali`, `today_jalali`, `pending_assignments`, `upcoming_exams`; `GET /api/calendar` → `{logs, notes, assignments, exams}` for heatmap dots; `GET /api/export` → includes assignments/exams; `GET /api/export/csv` → column `تاریخ شمسی`. |
| **Fixes** | `MIGRATIONS` now suppresses `1054`/`1060`/`Duplicate column`; `add_item` and `study_logs` have try/except fallbacks when `time_slot`/`priority`/`mood` columns missing. `subject` `PUT` handles `daily_goal` optional. |
| **Frontend** | Pure-JS `gregorianToJalali` + `toJalali()` + `jalaliMonthName()` mirrored from backend (no extra lib). Header shows `امروز 1405/05/31`. `weekLabel` shows `1405/05/31 تا 1405/06/06`. Stats badges `📝 N تکلیف`, `📅 N امتحان`. Log rows show `log_date_jalali`. Calendar: `calMonthLabel` = `شهریور 1405 — 2026-08`, cells show both Gregorian day + Jalali day, intensity via study minutes, dots `amber=assignment, red=exam, 📝=note`. Forms: assignment (title*, due_date*, subject, priority, desc, jalali hint), exams (title*, exam_date*, time, location, desc). Filters `همه/مانده/انجام‌شده`. Overdue ring, `days_remaining` badges `امروز!/فردا/N روز مانده`. Chart x-labels use `log_date_jalali.slice(5)`. |

## Jalali Patterns (reusable)

- **Backend with optional jdatetime:** try `import jdatetime` → `jdatetime.date.fromgregorian(day, month, year)` → `f"{j.year:04d}/{j.month:02d}/{j.day:02d}"`; if ImportError use hand-rolled 33-cycle (`leap in (1,5,9,13,17,22,26,30)`). Wrap in `try` so `pip install jdatetime` missing never crashes app.
- **Enrichment helper:**
  ```python
  def enrich_jalali(obj, fields):
      for f in fields:
          if f in obj and obj[f]:
              obj[f + '_jalali'] = to_jalali_str(str(obj[f]))
  ```
  Call after every `str(date)` conversion before `jsonify`.
- **Frontend no-dependency mirror:** same algorithm in JS so hints (`logJalali`, `assignDueJalali`, `examJalali`) update instantly on `input[type=date] change` without round-trip.
- **Calendar header:** `gregorianToJalali(y,m,1)` → `jalaliMonthName(jm) + ' ' + jy + ' — ' + calMonth`.

## Assignments / Exams Patterns

- **Assignments status toggle:** `PATCH /api/assignments/<id> {status: 'done'|'pending'}` — single-field update so checkbox is cheap. List query `ORDER BY due_date ASC` so overdue on top.
- **Exams countdown:** `days_remaining = (exam_date - date.today()).days` computed in `GET /api/exams` (not stored). Frontend badge logic: `0→امروز! 1→فردا 2-7→amber  <0→X روز پیش`.
- **FK `ON DELETE SET NULL`:** deleting a subject keeps assignments/exams (orphaned to "عمومی") instead of cascade — preserves user data.

## Railway Deployment Lessons (v3)

1. **`deploymentRedeploy(usePreviousImageTag:false)` reuses image cache** — `buildLogs` only `scheduling build` + `image push` (no `pip install`), `GET /` still V2 despite GitHub HEAD at V3. Fix that worked: bump `requirements.txt` with `# cache-bust <epoch>` or set `NIXPACKS_NO_CACHE=1` via `variableCollectionUpsert`, then `deploymentRedeploy` → real build shows `Collecting jdatetime`, `Successfully installed ...`. Remove `NIXPACKS_NO_CACHE` after via `variableDelete` to avoid slow future builds. `BUILD_ID` comment in `app.py` helps verify which image is live.
2. **`githubRepoDeploy(projectId, repo, branch, environmentId) -> String!`** returns a deployment ID string, but `query deployment(id:)` + `buildLogs(deploymentId:)` may return `Deployment not found` if the service hasn't created a deployment yet — don't poll that ID. Poll `deployments(projectId, serviceId)` instead; variable change auto-creates a new `BUILDING` deployment.
3. **`serviceInstanceRedeploy(serviceId, environmentId) -> Boolean!`** — no selection set (`{ id }` is invalid GraphQL). Use `api '{ mutation { serviceInstanceRedeploy(serviceId:"...", environmentId:"...") } }'`.
4. **Verification:** `curl https://app.up.railway.app/` must contain `نسخه ۳` + `تکالیف` + `toJalali`; `GET /api/stats` must have `today_jalali`, `week_start_jalali`; `GET /api/assignments` must be `[]` not `404` before declaring success. Compare remote template via `GET /repos/{owner}/{repo}/contents/templates/index.html?ref=main` (base64 decode) vs live `GET /`.

## Verification (v3 live after `8474f896 SUCCESS`)

```
GET /                    → 200 v3=True len=60927
GET /health              → {"db":"connected"}
GET /api/stats           → today_jalali=1405/05/31 week_start_jalali=1405/05/31
GET /api/assignments     → [] (200, not 404)
GET /api/exams           → [] (200)
GET /api/calendar?month=2026-08 → {logs, notes, assignments, exams}
POST /api/assignments {title,due_date:"2026-08-25"} → due_date_jalali=1405/06/03
POST /api/exams {title,exam_date:"2026-09-05"} → days_remaining=14 (via GET)
CSV                      → header includes "تاریخ شمسی"
```
