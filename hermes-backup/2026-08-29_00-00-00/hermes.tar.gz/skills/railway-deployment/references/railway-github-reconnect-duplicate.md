# Railway — GitHub Repo not found + Duplicate Service (2026-08-22)

## Symptom (screenshots)
- Dashboard production → Source: `penalerko/Panel` + red `GitHub Repo not found`.
- Service list shows TWO services with same Source: `weekly-planner` (7c4a0f68…) and `Panel` (8be31502…), both `source.repo == "penalerko/Panel"`, both Online.
- Live URL `weekly-planner-production-fcf8.up.railway.app` still serves OLD build (e.g. `todayLocal` missing) even after pushing new commit to `main`.

## Why
- Railway GitHub App lost access (token rotation, repo visibility change, or org permission revoked). Connection stays visually linked but can't fetch new commits → "Repo not found".
- Duplicate service created during fallback `serviceCreate` calls while `railway add --database` was Unauthorized. Wastes build minutes and confuses which service owns domains/env vars.

## Diagnostic
```bash
# Which service is actually connected to which repo?
RAILWAY_API_TOKEN=$TOKEN railway api 'query { service(id: "7c4a0f68-4d2f-4980-a82a-3819afa6c171") { id name serviceInstances { edges { node { id source { repo } } } } } }'
# Repeat for 8be31502… — both returned repo=penalerko/Panel → duplicate.

# Check recent deploys — only one service should have SUCCESS after each push
RAILWAY_API_TOKEN=$TOKEN railway api 'query { deployments(input: { projectId: "3da1520f-28a2-4c92-ae97-9b8840338c68"}) { edges { node { serviceId status createdAt } } } }'
```

## Fix
1. **Reconnect GitHub App**: Railway Dashboard → Project `weekly-planner` (3da1520f…) → Settings → Integrations → GitHub → Reconnect / Reinstall for org `penalerko`. Grant access to `penalerko/Panel`.
2. **Delete duplicate**: keep the service that owns the domain + env vars (weekly-planner 7c4a0f68…). Delete the other via Dashboard (Service → Settings → Delete Service) or GraphQL:
   ```bash
   RAILWAY_API_TOKEN=$TOKEN railway api 'mutation { serviceDelete(id: "8be31502-44d1-4264-9c4b-83f19948c3de") }'
   ```
3. **Force deploy**: after reconnect, push a commit or trigger via `variableCollectionUpsert(variable: NIXPACKS_BUST="<epoch>")` then poll `deployments` until SUCCESS, then `variableDelete`.
4. **User hard refresh**: browser cache can keep old HTML. Tell user to hard-refresh (Ctrl+Shift+R / clear site data) after deploy shows SUCCESS.

## Prevention
- Never create a fallback service named differently (`Panel`) when `weekly-planner` already exists — check `project { services { edges { node { name } } } }` before `serviceCreate`.
- After fixing Tehran timezone / Jalali dates (zoneinfo Asia/Tehran; `todayLocal()` not `toISOString()`), bump `BUILD_ID` + `# cache-bust` in requirements so Railway detects change even with same file hash (nixpacks cache).
