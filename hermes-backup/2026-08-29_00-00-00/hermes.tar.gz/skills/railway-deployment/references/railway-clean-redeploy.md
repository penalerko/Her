# Railway — Clean Redeploy (nuke & recreate) 2026-08-22

## When to use
Dashboard shows `GitHub Repo not found` (even though repo exists public) + duplicate services both `source.repo == "penalerko/Panel"` + live domain serves stale build after pushes. User asked to delete entire project and redeploy clean.

## Why not projectCreate with repo directly
`projectCreate(repo: {fullRepoName, branch})` returns `Failed to fetch repository files` when Railway GitHub App lacks access. Create empty project first, then add services individually.

## Steps (GraphQL v2, RAILWAY_API_TOKEN)

```bash
TOKEN=$RAILWAY_API_TOKEN
WS=d2682e2e-6f88-4a88-af6b-899aebfaf170
PID_OLD=3da1520f-28a2-4c92-ae97-9b8840338c68

# 1. Delete old project
railway api 'mutation { projectDelete(id: "'$PID_OLD'") }'

# 2. Wait 30s — workspace rate limit: 1 project per 30s
sleep 32

# 3. Create empty project
NEW_PID=$(railway api 'mutation { projectCreate(input: { name: "weekly-planner", workspaceId: "'$WS'" }) { id } }' | jq -r .data.projectCreate.id)
# → 39fc10e0-b761-40b1-a872-8586906f9c42

# 4. Get production env id
railway api 'query { project(id: "'$NEW_PID'") { environments { edges { node { id name } } } } }'
# → bf78db10-2853-4592-833d-0d67d475fc59

# 5. MySQL as image service (pluginCreate → Not Authorized)
MYSQL_SID=$(railway api 'mutation { serviceCreate(input: { projectId: "'$NEW_PID'", environmentId: "'$ENV'", name: "mysql", source: { image: "mysql:8" } }) { id } }' | jq -r .data.serviceCreate.id)

# 6. MySQL env vars
railway api 'mutation { variableCollectionUpsert(input: { projectId: "'$NEW_PID'", environmentId: "'$ENV'", serviceId: "'$MYSQL_SID'", variables: { MYSQL_ROOT_PASSWORD: "xxx", MYSQL_DATABASE: "weekly_planner", MYSQL_USER: "planner", MYSQL_PASSWORD: "xxx" } }) }'

# 7. Web service from GitHub (must be AFTER project exists)
WEB_SID=$(railway api 'mutation { serviceCreate(input: { projectId: "'$NEW_PID'", environmentId: "'$ENV'", name: "weekly-planner", source: { repo: "penalerko/Panel" } }) { id } }' | jq -r .data.serviceCreate.id)

# 8. Web env vars (private host = mysql.railway.internal)
railway api 'mutation { variableCollectionUpsert(input: { projectId: "'$NEW_PID'", environmentId: "'$ENV'", serviceId: "'$WEB_SID'", variables: { MYSQLHOST: "mysql.railway.internal", MYSQLPORT: "3306", MYSQLUSER: "planner", MYSQLPASSWORD: "xxx", MYSQLDATABASE: "weekly_planner", SECRET_KEY: "..." } }) }'

# 9. Domain — NO projectId field (only environmentId + serviceId)
railway api 'mutation { serviceDomainCreate(input: { environmentId: "'$ENV'", serviceId: "'$WEB_SID'" }) { id domain } }'
# → weekly-planner-production-9aca.up.railway.app

# 10. Poll until SUCCESS
railway api 'query { deployments(input: { projectId: "'$NEW_PID'", serviceId: "'$WEB_SID'"}) { edges { node { id status } } } }'
# Check logs: deploymentLogs(deploymentId, limit: 10)
```

## Pitfalls
- `serviceDomainCreate` input is `{environmentId, serviceId, targetPort?}` — adding `projectId` → GRAPHQL_VALIDATION_FAILED.
- `pluginCreate(name: "mysql")` always `Not Authorized` with API token; use `serviceCreate image: "mysql:8"`.
- `serviceCreate(source: {repo})` without prior `projectCreate(repo:...)` avoids fetch error.
- Old domain `fcf8` dies with project; new domain `9aca` is the source of truth — update any hardcoded check scripts.
