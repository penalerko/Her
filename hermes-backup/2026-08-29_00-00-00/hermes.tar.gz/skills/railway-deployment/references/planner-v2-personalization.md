# Weekly Planner v2 — Personalization & Cache-Bust Architecture

**Date:** 2026-08-22 **Project:** `3da1520f-28a2-4c92-ae97-9b8840338c68` **Service:** `7c4a0f68-4d2f-4980-a82a-3819afa6c171`
**Stack:** Flask + MySQL 8.4 (Railway) + PyMySQL + gunicorn 23 + Tailwind + Chart.js

## What v2 Added (over v1 Sat–Fri grid + subjects + logs + chart)

| Area | v1 | v2 |
|------|----|----|
| DB | 4 tables (subjects, weekly_plans, plan_items, study_logs) | + 5 tables: `goals`, `daily_notes`, `pomodoro_sessions`, `app_settings` + 4 migrations (`daily_goal`, `time_slot`, `priority`, `mood`) |
| Backend | `/api/subjects`, `/plans`, `/plan-items`, `/logs`, `/stats` | + `/api/settings` (GET/PUT), `/goals` (+ `/goals/progress`), `/notes`, `/pomodoro`, `/calendar?month=`, `/export` (JSON) + `/export/csv` |
| Stats | `planned`, `actual`, `trend`, `total_all`, `week_total` | + `streak` (consecutive days), `weekly_target`, `weekly_progress` |
| Frontend | Light, single column, 674 lines | Dark mode (class), glass header, streak badge, weekly progress bar, pomodoro timer (25/5/15 configurable, 4-dot cycle, Notification API + audio), goals with progress bars, subject daily_goal, slot/priority in grid, searchable/filterable logs + mood, daily notes, heatmap calendar (Sat start, intensity 4 levels), settings modal (daily_goal, accent, pomodoro timings, theme auto/light/dark), 4 templates (konkur/zaban/barname/motale), export CSV+JSON, copy-last-week |

## Reusable Personalization Patterns

- **Settings as DB key/value + localStorage fallback:** `app_settings` (`key` PK, `value` TEXT) seeded via `INSERT ... ON DUPLICATE KEY UPDATE`; frontend reads `/api/settings` then falls back to `localStorage` if DB unreachable. `PUT /api/settings` bulk upserts. Theme resolves `light|dark|auto` against `matchMedia(prefers-color-scheme)`.
- **Lazy DB init:** `@app.before_request` with `_inited` guard + `MIGRATIONS` list (`ALTER TABLE ... ADD COLUMN` with `1060`/`Duplicate column` suppression) — avoids blocking import and survives first deploy before MySQL ready. `GET /health` always 200.
- **Pomodoro as sessions table:** `pomodoro_sessions(subject_id, duration_minutes, completed, started_at)` — frontend `setInterval` counts down, on `work→break` posts `POST /api/pomodoro`, increments `pomoCount%4` for long break. `GET /api/pomodoro` aggregates today's count/total for header.
- **Calendar heatmap:** `GET /api/calendar?month=YYYY-MM` returns `{logs:{date:{total,cnt}}, notes:[dates]}` — frontend computes intensity thresholds `<30 indigo-200, <90 indigo-400, <180 indigo-600, else violet-700`.
- **Template seeding:** `applyTemplate('konkur')` posts preset subjects via `POST /api/subjects` — no hard-coded DB seed beyond demo 5; idempotent because `ON DUPLICATE KEY UPDATE name=name`.

## Cache-Bust & Stale-Image Trap (critical)

**Symptom:** `deployment status: SUCCESS` but `GET /` still V1 (`title` without `نسخه ۲`), `buildLogs` only `scheduling build` + `image push` (no `pip install`).

**Cause:** Nixpacks layer cache + `deploymentRedeploy(usePreviousImageTag:false)` still hits cache if no file hash changed. GitHub HEAD at `f6023fd` (V2) but Railway served image from before `80e4ba6`.

**Fix that worked:** mutate `requirements.txt`:
```
Flask==3.1.0
pymysql==1.1.1
python-dotenv==1.0.1
gunicorn==23.0.0
cryptography==44.0.0
# cache-bust 1787422408
```
Push via Contents API, then `deploymentRedeploy(id, usePreviousImageTag:false)` → `buildLogs` now shows `pip install`, `health` returns `{"db":"connected"}` and `/` contains `نسخه ۲` + `پومودورو`.

**Detection:** compare `curl https://app.up.railway.app/` vs `GET /repos/.../contents/templates/index.html?ref=main` (base64 decode). If mismatch, force rebuild. Also add `BUILD_ID` comment to `app.py` for visibility.

**Related 502 fix:** domain `targetPort` must be `8080` (Railway `$PORT`), not `5000` — `serviceDomainUpdate(..., targetPort:8080)` + `healthcheckPath:/health`.
