# Hermes GitHub Backup — Every 9h (Proven 2026-08-22)

Repo: `penalerko/Panel`, branch `main`, PAT fine-grained `github_pat_...` with `Contents: Read & Write`.

## Script
`~/.hermes/scripts/hermes_github_backup.py` — tars `config.yaml, SOUL.md, memories, skills, cron, state, sessions, auth.json, channel_directory.json` (excludes `cache, logs, audio_cache, image_cache, kanban.db, state.db-wal, models_dev_cache.json`). Creates `hermes-backup/<YYYY-MM-DD_HH-MM-SS>/hermes.tar.gz` (~2.4 MB) + `manifest.json` + updates `hermes-backup/latest.json` and `hermes-backup/README.md` via `PUT /repos/{owner}/{repo}/contents/{path}` with `Authorization: Bearer <PAT>`.

Token file: `~/.hermes/github_backup_token` (600), env fallback `GITHUB_BACKUP_TOKEN`.

## Cron
`0 */9 * * *`, `no_agent:true`, `script:hermes_github_backup.py`, prompt must be ASCII English — Persian ZWNJ U+200C in prompt is blocked (`Blocked: prompt contains invisible unicode U+200C`). Use `Hermes auto backup to GitHub every 9 hours`.

Test: `python3 ~/.hermes/scripts/hermes_github_backup.py` → `✅ Archive uploaded`.

## Weekly Planner Stack (same repo)
Flask 3.1 + PyMySQL 1.1 + gunicorn, `schema.sql` auto-runs on startup (handles `Unknown database` → `CREATE DATABASE`), week Saturday-start `offset=(weekday-5)%7`, Persian UI Vazirmatn RTL days `شنبه..جمعه`, tables `subjects, weekly_plans, plan_items, study_logs`, `Procfile: web: gunicorn app:app --bind 0.0.0.0:$PORT`, `runtime.txt: python-3.11.9`. Env fallback chain: `MYSQL_URL`/`DATABASE_URL` → `MYSQLHOST`/`MYSQLUSER`/`MYSQLPASSWORD`/`MYSQLDATABASE` → `DB_HOST`/`DB_USER`/`DB_PASSWORD`/`DB_NAME` + `mysql.railway.internal:3306`.
