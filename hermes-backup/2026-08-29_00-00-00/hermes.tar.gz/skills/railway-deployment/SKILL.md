---
name: railway-deployment
description: "Use when deploying apps to Railway."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [Railway, PaaS, Deployment, MySQL, Docker, GitHub]
    related_skills: [github-repo-management, github-auth]
---

# Railway Deployment

Deploy Flask/Node/etc apps to Railway via CLI (`@railway/cli`) and GraphQL API (`backboard.railway.app/graphql/v2`). Covers project/service creation, database provisioning, env vars, and GitHub-connected deploys.

## Prerequisites

- `npm i -g @railway/cli` (v5.43+)
- Token from Railway dashboard -> Account -> Tokens. Use `RAILWAY_API_TOKEN`, **not** `RAILWAY_TOKEN` (latter is deprecated/workspace-scoped and returns 401 on `whoami`/`up`).
- Verify: `RAILWAY_API_TOKEN=<token> railway whoami --json` should return `email` + `workspaces`.

## 1. Project Setup

```bash
# Create new project (fails if free-plan resource limit exceeded -> reuse existing project)
RAILWAY_API_TOKEN=$TOKEN railway init --name <project> --workspace <workspace-id> --json

# Link existing project (required when `railway up` says Unauthorized)
RAILWAY_API_TOKEN=$TOKEN railway link -p <projectId> -e production --json
# Config written to /data/.railway/config.json (or ~/.railway). Check:
cat /data/.railway/config.json
```

**Pitfall:** `railway add --database mysql` often returns `Unauthorized` even with valid `RAILWAY_API_TOKEN`. Use GraphQL `serviceCreate` instead (see §2).

## 2. Create Services via GraphQL (reliable)

```bash
# App service
curl -s -H "Authorization: Bearer $RAILWAY_API_TOKEN" -H "Content-Type: application/json" \
  -d '{"query":"mutation { serviceCreate(input: { projectId: \"'"$PROJECT_ID"'\", name: \"web\", source: { image: \"python:3.11-slim\" } }) { id name } }"}' \
  https://backboard.railway.app/graphql/v2

# MySQL service
curl -s -H "Authorization: Bearer $RAILWAY_API_TOKEN" -H "Content-Type: application/json" \
  -d '{"query":"mutation { serviceCreate(input: { projectId: \"'"$PROJECT_ID"'\", name: \"mysql\", source: { image: \"mysql:8\" } }) { id name } }"}' \
  https://backboard.railway.app/graphql/v2
```

Update linked service in `/data/.railway/config.json` -> `projects["<path>"].service = "<serviceId>"` if CLI auto-linked wrong service.

## 3. Environment Variables via GraphQL

```bash
# MySQL vars
curl -s -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"query":"mutation { variableCollectionUpsert(input: { projectId: \"'"$PID"'\", environmentId: \"'"$EID"'\", serviceId: \"'"$MYSQL_SID"'\", variables: { MYSQL_ROOT_PASSWORD: \"planner123\", MYSQL_DATABASE: \"weekly_planner\" } }) }"}' \
  https://backboard.railway.app/graphql/v2

# App vars (private networking host = mysql.railway.internal)
curl -s -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"query":"mutation { variableCollectionUpsert(input: { projectId: \"'"$PID"'\", environmentId: \"'"$EID"'\", serviceId: \"'"$APP_SID"'\", variables: { DB_HOST: \"mysql.railway.internal\", DB_PORT: \"3306\", DB_USER: \"root\", DB_PASSWORD: \"planner123\", DB_NAME: \"weekly_planner\" } }) }"}' \
  https://backboard.railway.app/graphql/v2

# Verify
curl -s -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"query":"query { variables(projectId: \"'"$PID"'\", environmentId: \"'"$EID"'\", serviceId: \"'"$APP_SID"'") }"}' \
  https://backboard.railway.app/graphql/v2 | python3 -m json.tool
```

App code should read `MYSQL_URL`/`DATABASE_URL` first, then fall back to `MYSQLHOST`/`MYSQLUSER`/`MYSQLPASSWORD`/`MYSQLDATABASE` and finally `DB_HOST` etc. -> covers both Railway plugin and manual GraphQL vars.

## 4. GitHub-Connected Deploy (preferred over `railway up`)

`railway up` (local upload) frequently returns `Unauthorized` with API tokens. Use GitHub source instead:

1. Push repo to GitHub (see §5 for fine-grained PAT caveats).
2. Connect via GraphQL `serviceConnect` or dashboard: Service -> Settings -> Source -> Connect Repo.
3. `Procfile`: `web: gunicorn app:app --bind 0.0.0.0:$PORT`
4. `runtime.txt` / `NIXPACKS_PYTHON_VERSION` for Python version.

## 5. GitHub Fine-Grained PAT Pitfalls

- API: always `Authorization: Bearer <pat>` (not `token` or `user:pat`). Test: `curl -H "Authorization: Bearer $PAT" https://api.github.com/user` -> `login` ok, but `POST /user/repos` may return `403 Resource not accessible by personal access token` if PAT was created without **Repository -> Contents: Read & Write** + **Administration: Read & Write** on the target org/repo.
- Git push: `https://oauth2:<pat>@github.com/owner/repo.git` or `https://x-access-token:<pat>@github.com/owner/repo.git` — plain `https://<pat>@github.com/...` and `username:pat` often 403 with fine-grained PATs. If push still 403, fallback to Contents API `PUT /repos/{owner}/{repo}/contents/{path}` (base64 content) — works even when git push is blocked.
- If repo creation via API 403, ask user to create repo manually in UI, then push.

## 6. Verify

```bash
RAILWAY_API_TOKEN=$TOKEN railway api 'query { project(id: "'$PID'") { services { edges { node { id name } } } } }'
# Check deployments/logs after connect (dashboard is authoritative when CLI says Unauthorized)
```

## References

- `references/railway-graphql-vars.md` — variableCollectionUpsert examples
- `references/railway-github-pat.md` — fine-grained PAT permission matrix
