---
name: Multi-Platform Meme Search
description: Find memes across platforms with URL-encoded searches.
tags: [memes, search, multi-platform, persian, farsi, content-discovery]
---

# Multi-Platform Meme and Viral Content Search

## When to Use

- User asks to find a specific meme, viral video, or internet content
- Content might exist on multiple platforms (social media, video sites, messaging apps)
- Content is in non-English languages (Persian/Farsi, Arabic, etc.) requiring proper URL encoding
- User provides platform handles/channels to search (Telegram channels, Instagram hashtags)
- Need systematic search across web, video platforms, and social networks

## Approach

### 1. Gather Context

Ask the user for:
- **Description of content**: What is it? (meme format, character, scene)
- **Language/region**: Persian, English, Arabic, etc.
- **Platform hints**: Where did they see it? (Telegram, Instagram, YouTube)
- **Specific channels/accounts**: Any known sources? (@channelname, hashtags)
- **Keywords**: Text on the meme, character names, audio/music

### 2. Generate Search URLs Programmatically

**DO NOT** just provide suggestions. **CREATE A PYTHON SCRIPT** that:
- Generates properly URL-encoded search links for each platform
- Uses `urllib.parse.quote()` for non-ASCII characters (Persian, Arabic, emoji)
- Saves all links to a JSON file for easy access
- Prints clickable links the user can open

```python
from urllib.parse import quote
import json

def search_google(query):
    return f"https://www.google.com/search?q={quote(query)}"

def search_youtube(query):
    return f"https://www.youtube.com/results?search_query={quote(query)}"

def search_aparat(query):
    return f"https://www.aparat.com/search?query={quote(query)}"

def search_instagram(hashtag):
    tag = hashtag.replace(" ", "_").replace("#", "")
    return f"https://www.instagram.com/explore/tags/{tag}/"

def telegram_channel_link(channel):
    return f"https://t.me/{channel}"
```

### 3. Platform-Specific Strategies

#### Google
- Use multiple keyword variations (English + native language)
- Try: `"<content name>" <language> meme`, `"<content name>" viral video`

#### YouTube
- Search both English and native language terms
- Try: channel names, character names, song lyrics from the content

#### Aparat (Persian/Iranian content)
- Primary Persian video platform
- Use Persian keywords: `میم`, `خنده‌دار`, `دوبله`, `فحش` (for dubbed/funny content)

#### Instagram
- Search hashtags: `#میم_فارسی`, `#meme`, `#<contentname>`
- Explore tags methodically

#### Telegram
- Provide **direct channel links**: `https://t.me/channelname`
- Instruct user to use in-app search (🔍 icon in channel)
- Telegram content is not indexed by Google

**Common Persian meme channels:**
- `@persianmemes`
- `@funnypersian`
- `@iranianimemes`
- `@memegraph_ir`
- `@funnydubbing`

### 4. Execute and Save Results

```python
# Run the script
python search_meme_multi_platform.py

# Save results
results = {
    "google_searches": [...],
    "youtube_searches": [...],
    "aparat_searches": [...],
    "instagram_hashtags": [...],
    "telegram_channels": [...]
}

with open("search_results.json", "w", encoding="utf-8") as f:
    json.dump(results, f, ensure_ascii=False, indent=2)
```

## Pitfalls

❌ **Don't** just suggest keywords — generate actual clickable URLs
❌ **Don't** forget URL encoding for non-ASCII (Persian, Arabic, Chinese, emoji)
❌ **Don't** assume content is in English — ask about language first
❌ **Don't** skip Telegram — it's often the primary source for regional memes
❌ **Don't** give up if Google doesn't find it — try platform-native search

✅ **Do** create a runnable Python script that outputs all links
✅ **Do** use `urllib.parse.quote()` for proper encoding
✅ **Do** save results to JSON for easy reference
✅ **Do** provide instructions for platform-specific search (Telegram in-app)
✅ **Do** try multiple keyword variations (translated terms, transliteration)

## Output Format

Provide:
1. **Executable Python script** saved to file
2. **Run the script** and show output
3. **JSON file** with all search links organized by platform
4. **User instructions** for manual search steps (especially Telegram)

## Notes

- **Telegram requires in-app search**: Web links only open channels, not search results
- **Persian content**: Aparat > YouTube for Iranian-specific memes
- **Recent content**: Instagram/Telegram > YouTube/Google (fresher sources)
- **Viral spread pattern**: Often Telegram → Instagram → YouTube → Google indexing
