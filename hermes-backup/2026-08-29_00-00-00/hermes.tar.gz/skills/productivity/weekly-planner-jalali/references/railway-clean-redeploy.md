# Railway Clean Redeploy — when Source shows "GitHub Repo not found"

When the weekly-planner service is bound to `penalerko/Panel` but Railway shows `GitHub Repo not found` (red banner), a normal `serviceInstanceDeploy(latestCommit:true)` on the same project still fixed it after deleting the duplicate `Panel` service. If the link is irreparably broken, do a **clean project redeploy**.

## Copy-paste GraphQL

```graphql
# 1. Delete old (if irreparable)
mutation { projectDelete(id: "OLD_PID") }

# 2. Create new project — NO repo field here (it triggers "Failed to fetch repository files" if Panel root is misread)
#    Rate limit: 1 project per 30s per workspace
mutation { projectCreate(input: { name: "weekly-planner", workspaceId: "d2682e2e-6f88-4a88-af6b-899aebfaf170" }) { id name } }

# 3. MySQL as Docker image (pluginCreate is Not Authorized on this workspace)
mutation { serviceCreate(input: { projectId: "NEW_PID", environmentId: "NEW_ENV", name: "mysql", source: { image: "mysql:8" } }) { id name } }

# 4. MySQL vars
mutation { variableCollectionUpsert(input: { projectId: "NEW_PID", environmentId: "NEW_ENV", serviceId: "MYSQL_SID", variables: { MYSQL_ROOT_PASSWORD: "weekly_planner_root_2024", MYSQL_DATABASE: "weekly_planner", MYSQL_USER: "planner", MYSQL_PASSWORD: "planner_pass_2024" } }) }

# 5. Web from GitHub
mutation { serviceCreate(input: { projectId: "NEW_PID", environmentId: "NEW_ENV", name: "weekly-planner", source: { repo: "penalerko/Panel" } }) { id name } }

# 6. Web DB vars — set BOTH MYSQL* and DB_* (app reads either)
mutation { variableCollectionUpsert(input: { projectId: "NEW_PID", environmentId: "NEW_ENV", serviceId: "WEB_SID", variables: { MYSQLHOST: "mysql.railway.internal", MYSQLPORT: "3306", MYSQLUSER: "planner", MYSQLPASSWORD: "planner_pass_2024", MYSQLDATABASE: "weekly_planner", DB_HOST: "mysql.railway.internal", DB_PORT: "3306", DB_USER: "planner", DB_PASSWORD: "planner_pass_2024", DB_NAME: "weekly_planner", SECRET_KEY: "weekly-planner-secret-2024" } }) }

# 7. Domain — NOTE: no projectId field (validation fails if included)
mutation { serviceDomainCreate(input: { environmentId: "NEW_ENV", serviceId: "WEB_SID" }) { id domain } }
# alternative with explicit port:
# mutation { serviceDomainCreate(input: { environmentId: "NEW_ENV", serviceId: "WEB_SID", targetPort: 8080 }) { id domain } }

# 8. Deploy (after any push, pull latest commit)
mutation { serviceInstanceDeploy(serviceId: "WEB_SID", environmentId: "NEW_ENV", latestCommit: true) }
# returns Boolean! — no subfields. Poll:
query { deployments(input: { projectId: "NEW_PID", serviceId: "WEB_SID"}) { edges { node { id status } } } }

# 9. Also works: serviceInstanceDeployV2(serviceId, environmentId)
```

## Working IDs (2026-08-22 clean project)

- `NEW_PID=39fc10e0-b761-40b1-a872-8586906f9c42` `NEW_ENV=bf78db10-2853-4592-833d-0d67d475fc59`
- `MYSQL_SID=3d5735be-ddfb-4ff6-9b29-9d5d8bd81148` `WEB_SID=f59227d6-72e9-4084-9735-12204810fa8b`
- `domain=weekly-planner-production-9aca.up.railway.app` (old `fcf8` is dead/404 after delete)
- Duplicate `Panel` service removed via `serviceDelete(id:"8be31502-44d1-4264-9c4b-83f19948c3de")` before the clean redeploy.

## Why same-project deploy broke earlier

- Live HTML (`GET /?t=<ts>`) still served old `g_d_m` Jalali while GitHub raw already had `Intl` — drift proved no redeploy happened. Fix: always use `latestCommit:true` (not bare `serviceInstanceDeploy` without it) so Railway pulls the new commit.

## Verification after

- `GET /api/stats today_jalali == jdatetime(Asia/Tehran today)` (e.g. `1405/06/01` on 2026-08-23)
- `GET / vs GET https://raw.githubusercontent.com/penalerko/Panel/main/templates/index.html` both contain `Intl.DateTimeFormat` + `۳.۱`
- 22-check audit passes (see SKILL.md).
