# Tehran Timezone + Jalali Dynamic Dates — v3.4 (2026-08-22)

## Problem
- Railway runs in UTC. User reported 2026-08-22 22:33 Tehran but backend still used `date.today()` (UTC 19:03) → off by 1 day after 20:30 Tehran, `today_jalali` wrong, `days_remaining` off, calendar shifted.
- Frontend used `new Date().toISOString()` (UTC) for `todayG()` and `calMonth` and `addDays` parsing → same shift + hard-coded-looking literal.

## Backend fix (app.py)
```python
from zoneinfo import ZoneInfo
TEHRAN = ZoneInfo("Asia/Tehran")
def tehran_today(): return datetime.now(TEHRAN).date()
def tehran_now():   return datetime.now(TEHRAN)
# Replace 8 sites: jalali_today_str, week_range, exams days_remaining, stats today,
# notes GET/POST, calendar month default, export exported_at
```
Verify: `GET /api/stats today_jalali` must be `1405/05/31` for 2026-08-22 Tehran (Saturday).

## Frontend fix (templates/index.html)
```js
function todayLocal(){ const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}` }
function localMonthStr(d=new Date()){ return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}` }
function todayG(){ return todayLocal(); }
function addDays(gdate,n){ const [yy,mm,dd]=gdate.split('-').map(Number); const d=new Date(yy,mm-1,dd); d.setDate(d.getDate()+n); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}` }
let calMonth = localMonthStr();
// Calendar label: `${jalaliMonthName(jm)} ${jy} — شمسی` (no Gregorian string)
// addDays and localMonthStr avoid toISOString UTC path entirely
```

## How to verify dynamic (not hardcoded)
- Backend: `GET /api/stats week_start` changes with real Tehran date, not literal; create assignment `due_date = tehran_today()+3` → `due_date_jalali` auto 1405/06/03.
- Frontend: HTML must have `todayLocal` and zero `toISOString`; `jShort` per day in week grid uses `toJalali(addDays(currentWeekStart, idx))`.
