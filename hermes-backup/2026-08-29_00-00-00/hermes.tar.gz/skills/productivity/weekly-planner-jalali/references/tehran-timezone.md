# Tehran timezone — why every date froze

## Symptom
User said ۱۴۰۵/۰۵/۳۱ شنبه (2026-08-22) Tehran but every surface in planner showed a fixed old number: stats today_jalali, week grid dates, exam days_remaining, chart, calendar header.

## Root cause
- Backend used bare `date.today()` / `datetime.now()` (UTC on Railway). Between 20:30-23:59 UTC, Tehran is already next day → off-by-one.
- Frontend used `new Date().toISOString().slice(0,10)` / `addDays` via `new Date(gdate)` (UTC parse) → same drift.
- 8 backend sites need fixing: `jalali_today_str`, `week_range`, `exams days_remaining`, `stats today/classic`, `notes GET/POST default`, `calendar month default`, `export exported_at`.

## Fix
```python
from zoneinfo import ZoneInfo
TEHRAN = ZoneInfo("Asia/Tehran")
def tehran_today(): return datetime.now(TEHRAN).date()
def tehran_now(): return datetime.now(TEHRAN)
# replace every date.today() -> tehran_today(), datetime.now() -> tehran_now()
```

```js
function todayLocal(){ const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}` }
function addDays(gdate,n){ const [yy,mm,dd]=gdate.split('-').map(Number); const d=new Date(yy,mm-1,dd); d.setDate(d.getDate()+n); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}` }
let calMonth = localMonthStr(); // not new Date().toISOString().slice(0,7)
function todayG(){ return todayLocal(); }
```

## Verify
- `GET /api/stats` → today_jalali == 1405/05/31, week_start == 2026-08-22
- HTML has `todayLocal` and zero `toISOString`
- Calendar label: `jalaliMonthName(jm) + " " + jy + " — شمسی"` only
- Duplicate code: 409 correctly, subjects stay 5 unique

## Lesson
Class-level rule: any Persian/Jalali app deployed on Railway (UTC) must use Asia/Tehran helpers from day one. Add to skill setup checklist.
