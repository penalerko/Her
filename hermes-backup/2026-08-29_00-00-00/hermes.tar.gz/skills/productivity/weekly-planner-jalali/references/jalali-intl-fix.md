# Jalali Intl Fix — مرداد vs خرداد (2026-08-22)

**Bug:** Pure `g_d_m=[0,31,59,...]` gregorianToJalali drifted: `2026-08-22` → `1405/04/01` (خرداد) instead of correct `1405/05/31` (مرداد). Verified via `jdatetime==5.2.0`: `jdatetime.date.fromgregorian(2026,8,22) = 1405/05/31`, `2026-08-01 = 1405/05/10`.

**Root cause:** Hand-rolled 33-year cycle without accurate epoch offset; off by ~51 days for 1405.

**Fix frontend:**
```js
function gregorianToJalali(gy, gm, gd){
  try{
    const d=new Date(gy, gm-1, gd);
    const fmt=new Intl.DateTimeFormat('en-CA-u-ca-persian',{year:'numeric',month:'numeric',day:'numeric'});
    const parts=fmt.formatToParts(d);
    const get=t=>parts.find(p=>p.type===t).value;
    return [parseInt(get('year')), parseInt(get('month')), parseInt(get('day'))];
  }catch(e){}
  // fallback: jalaali-js 355666 epoch
  const g_d_m=[0,31,59,90,120,151,181,212,243,273,304,334];
  let gy2=(gm>2)?(gy+1):gy;
  let days=355666+365*gy+Math.floor((gy2+3)/4)-Math.floor((gy2+99)/100)+Math.floor((gy2+399)/400)+gd+g_d_m[gm-1];
  let jy=-1595+33*Math.floor(days/12053); days%=12053;
  jy+=4*Math.floor(days/1461); days%=1461;
  if(days>365){ jy+=Math.floor((days-1)/365); days=(days-1)%365; }
  let jm,jd;
  if(days<186){ jm=1+Math.floor(days/31); jd=1+days%31; }
  else{ days-=186; jm=7+Math.floor(days/30); jd=1+days%30; }
  return [jy,jm,jd];
}
```

**Fix backend:** Keep `jdatetime` in `requirements.txt` (already present). Backend already overrides `gregorian_to_jalali` via `jdatetime.date.fromgregorian` when installed — no change needed, but ensure `jdatetime==5.2.0` stays and no `runtime.txt` (mise attestation error).

**Calendar label:** `jalaliMonthName(jm_jd[1]) + " " + jm_jd[0] + " — شمسی"` only. For `2026-08` header must read `مرداد 1405 — شمسی`, not `خرداد`.

**Verification:** `GET /api/stats today_jalali == 1405/05/31`, `POST /api/assignments due 2026-08-25 → due_date_jalali 1405/06/03`, `GET / (html) includes Intl.DateTimeFormat && ۳.۱`.

**Session:** 2026-08-22 clean redeploy to `weekly-planner-production-9aca`. See also `railway-clean-redeploy.md`.
