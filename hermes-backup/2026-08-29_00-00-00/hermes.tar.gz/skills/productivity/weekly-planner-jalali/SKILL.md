---
name: weekly-planner-jalali
description: Persian Jalali weekly planner on Railway (Flask+MySQL).
---

# Weekly Planner (Persian Jalali) — Flask + MySQL on Railway

Use when building or maintaining a Persian weekly study planner: Flask + pymysql + gunicorn, MySQL on Railway, fully Jalali/Shamsi UI, deployed via GitHub repo.

## Stack
- Flask 3.1 / pymysql DictCursor / gunicorn --bind 0.0.0.0:$PORT / python-dotenv / jdatetime (optional, pure-python fallback kept)
- Procfile: `web: gunicorn app:app --bind 0.0.0.0:$PORT` — never hardcode port; Railway injects $PORT (usually 8080).
- requirements: Flask, pymysql, python-dotenv, gunicorn, cryptography, jdatetime. No runtime.txt (causes mise attestation error).

## Jalali — every surface must be Jalali
- Backend: `gregorian_to_jalali()` pure python + override via `jdatetime.date.fromgregorian` when installed; `to_jalali_str(gdate_str)` cached; `enrich_jalali(obj, fields)` adds `*_jalali` to every API response (plans, logs, assignments, exams, stats, export, calendar). Stats return `today_jalali`, `week_start_jalali`, `week_end_jalali`.
- Frontend: mirror conversion in JS (`gregorianToJalali`, `toJalali`, `jalaliMonthName`, `formatJalaliFull`). Week grid header shows `31 مرداد` + `1405/05/31`; logs bold `log_date_jalali`; calendar cells show Jalali day large, Gregorian small; CSV header `تاریخ شمسی`.
- Date handling: NEVER use `new Date().toISOString()` (UTC). Use local helpers:
  ```js
  function todayLocal(){ const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}` }
  function addDays(gdate,n){ const [yy,mm,dd]=gdate.split('-').map(Number); const d=new Date(yy,mm-1,dd); d.setDate(d.getDate()+n); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}` }
  let calMonth = localMonthStr();
  ```

## DB / dedup
- schema.sql: subjects, weekly_plans, plan_items (time_slot, priority, is_done), study_logs (mood), goals, daily_notes, pomodoro_sessions, assignments, exams, app_settings. Use `INSERT IGNORE` for seed.
- Migrations dedup BEFORE unique index: select duplicates by name keep MIN(id), delete rest, then `CREATE UNIQUE INDEX uq_subject_name ON subjects(name)`.
- POST /api/subjects: pre-check duplicate → 409 `درس «{name}» قبلاً وجود دارد`; also catch 1062/Duplicate. Frontend applyTemplate filters `new Set(subjects.map(s=>s.name))`.

## UI ordering
- Order: STATS → WEEK GRID (sec-grid) → MANAGE (SUBJECTS+GOALS, sec-manage) → TASKS (ASSIGNMENTS+EXAMS, sec-tasks) → ANALYTICS (CHART+POMO, sec-analytics) → HISTORY (LOG+NOTES+CALENDAR, sec-history). Sticky pill nav to anchors.
- Calendar label: `jalaliMonthName(jm) + " " + jy + " — شمسی"` only, no gregorian string.

## Railway deploy via GitHub
- Repo `penalerko/Panel` (planner), backup to `penalerko/Her`. Push via GitHub API (urllib+base64) with BUILD_ID bump + cache-bust.
- Trigger rebuild: `variableCollectionUpsert` dummy var `NIXPACKS_*_BUST` → poll `deployments` until SUCCESS → `variableDelete` (otherwise infinite loop).

## Verification
- 21-check audit after deploy: subjects 5 unique, dedup 409, plan jalali, plan_item time_slot/priority/done/delete, log jalali, goal per-subject+global, assignment jalali+toggle, exam jalali+days_remaining on GET, note jalali, pomodoro, calendar keys, CSV jalali header, export `exported_at_jalali`, HTML no UTC / has todayLocal. Recreate plan after dedup (cascade delete).
