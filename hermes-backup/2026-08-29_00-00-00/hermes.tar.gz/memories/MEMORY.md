User requires ALL dates in app to be Jalali/Shamsi (شمسی) — every section including week grid, logs, stats, calendar, export
§
User wants assignment (تکلیف) and exam (امتحان) features fully integrated with subjects and Jalali dates
§
User expects capabilities to be logically ordered with navigation and verified end-to-end (21-check audit) — not just added
§
User is frustrated by duplicate subjects and calendar/date UTC bugs — expects dedup via UNIQUE index + 409 and local date handling (todayLocal, addDays local)
§
User prefers Word documents right-aligned with B Nazanin font size 14, editable with header/footer and page numbers
§
User creates 9-step patient education guides for chronic diseases like diabetes and hypertension needing exact practical dialogue scripts per step based on a PDF structure