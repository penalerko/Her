User communicates primarily in Persian (Farsi) with informal colloquial style via Telegram (DM with 𝒜𝓂𝒾𝓇 ℳ𝒾𝒶𝓈).
§
User is interested in Persian meme culture, especially Biggie Cheese / Barnyard mouse rapper Persian dub memes and similar viral content.
§
User expects meme searches to be verified for accuracy across multiple platforms: Google, YouTube, Aparat, Instagram, and Telegram channels (@persianmemes, @funnypersian, @iranianimemes). Accuracy is explicitly important.
§
User is penalerko (GitHub penalerko, emails penalerko@atomicmail.io / aibotamir@atomicmail.io), Persian/Farsi speaker, communicates in Persian on Telegram
§
User wants weekly study planner (پلنر هفتگی) with MySQL, Flask backend, Persian UI, deployed on Railway, with weekly grid (Saturday-Friday), subjects, study logs and charts
§
User prefers Railway deployment via GitHub repo penalerko/Panel and wants automated Hermes backup to same repo every 9 hours (hermes-backup/<timestamp>/hermes.tar.gz)
§
User frequently requests meme searches (Biggie Cheese Persian dub, crying memes, etc.) and expects accurate links across Telegram, Google, YouTube, Instagram, Aparat